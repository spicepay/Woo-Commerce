# Woo-Commerce
Woo Commerce Plugin

Installation guide

1. Download the package.
2. Copy package contents to /<site_root>/wp-content/plugins/
3. Go to "Plugins->installed" and click "Activate" on SpicePay plugin.
4. WooCommerce -> Settings -> Checkout -> SpicePay
5. Set module settings:  
SpicePay site ID:  add new site on https://www.spicepay.com/tools.php, set in module settings site ID.
Spicepay Callback Secret: - set the same random secret string at when adding site and in opencart2 spicepay module settings. 
callback URL: http://your-site.com/?wc-api=WC_Gateway_Spicepay

6. Click "Save changes".

Find more info on https://www.spicepay.com

SpicePay Team

 
