<?php

/*
  Plugin Name: SpicePay
  Plugin URI:  https://www.spicepay.com/
  Description: SpicePay Plugin for WooCommerce
  Version: 1.0.0
  Author: https://www.spicepay.com
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/* Add a custom payment class to WC
------------------------------------------------------------ */
add_action('plugins_loaded', 'woocommerce_spicepay', 0);
function woocommerce_spicepay(){
    if (!class_exists('WC_Payment_Gateway'))
        return; // if the WC payment gateway class is not available, do nothing
    if(class_exists('WC_SPICEPAY'))
        return;
class WC_SPICEPAY extends WC_Payment_Gateway{
    public function __construct(){

    $plugin_dir = plugin_dir_url(__FILE__);

    global $woocommerce;

    $this->id = 'spicepay';
    $this->icon = apply_filters('woocommerce_spicepay_icon', ''.$plugin_dir.'spicepay.png');
    $this->has_fields = false;

    // Load the settings
    $this->init_form_fields();
    $this->init_settings();

    // Define user set variables
    $this->public_key = $this->get_option('public_key');
    $this->secret_key = $this->get_option('secret_key');
    $this->title = 'spicepay';
    $this->description = 'Payment with Spicepay';

    // Actions
    add_action('woocommerce_receipt_' . $this->id, array($this, 'receipt_page'));

    // Save options
    add_action('woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'process_admin_options' ) );

    // Payment listener/API hook
    add_action('woocommerce_api_wc_' . $this->id, array($this, 'callback'));


}

public function admin_options() {
?>
<h3><?php _e('spicepay', 'woocommerce'); ?></h3>
<p><?php _e('Setup Spicepay plugin.', 'woocommerce'); ?></p>

    <table class="form-table">

        <?php
        // Generate the HTML For the settings form.
        $this->generate_settings_html();
        ?>
    </table><!--/.form-table-->

    <?php
} // End admin_options()

function init_form_fields(){
    $this->form_fields = array(
        'enabled' => array(
            'title' => __('On/Off', 'woocommerce'),
            'type' => 'checkbox',
            'label' => __('On', 'woocommerce'),
            'default' => 'yes'
        ),
        'public_key' => array(
            'title' => __('Spicepay Site ID', 'woocommerce'),
            'type' => 'text',
            'description' => __('Copy Spicepay Site ID from spicepay.com/tools.php', 'woocommerce'),
            'default' => ''
        ),
        'secret_key' => array(
            'title' => __('Spicepay Callback Secret', 'woocommerce'),
            'type' => 'text',
            'description' => __('Copy SECRET KEY from spicepay.com/tools.php', 'woocommerce'),
            'default' => ''
        )

    );
}

/**
 * Generate form
 **/
public function generate_form($order_id){
    $order = new WC_Order( $order_id );

    $sum = number_format($order->order_total, 2, '.', '');
    $account = $order_id;
    
    
    $code = '<form action="https://www.spicepay.com/pay.php" method="POST"  target="_blank">'
    . '<input type="hidden" name="amountUSD" value="' . $sum . '" />'
    . '<input type="hidden" name="orderId" value="' . $order_id . '"/>'
    . '<input type="hidden" name="siteId" value="' . $this->public_key . '"/>'
    . '<input type="hidden" name="language" value="en"/>'
    . '<input type="submit" value="'.__('Pay', 'woocommerce').'"/>'
    . '</form>';

    return $code;
}

/**
 * Process the payment and return the result
 **/
function process_payment($order_id){
    $order = new WC_Order($order_id);

    return array(
        'result' => 'success',
        'redirect'	=> add_query_arg('order', $order->id, add_query_arg('key', $order->order_key, get_permalink(woocommerce_get_page_id('pay'))))
    );
}

function receipt_page($order){
	global $woocommerce;
	$woocommerce->cart->empty_cart();
    echo '<p>'.__('Thank you for your order, clease click the button below to pay.', 'woocommerce').'</p>';
    echo $this->generate_form($order);
}

function callback(){
   

    if (isset($_POST['paymentId']) && isset($_POST['orderId']) && isset($_POST['hash']) 
&& isset($_POST['paymentAmountBTC']) && isset($_POST['paymentAmountUSD']) 
&& isset($_POST['receivedAmountBTC']) && isset($_POST['receivedAmountUSD'])) {
        
        
        $paymentId = $_POST['paymentId'];
    $orderId = $_POST['orderId'];
    $hash = $_POST['hash'];    
    $clientId = $_POST['clientId'];
    $paymentAmountBTC = $_POST['paymentAmountBTC'];
    $paymentAmountUSD = $_POST['paymentAmountUSD'];
    $receivedAmountBTC = $_POST['receivedAmountBTC'];
    $receivedAmountUSD = $_POST['receivedAmountUSD'];
    $status = $_POST['status'];
    $secretCode = $this->secret_key;
    $order = new WC_Order( $orderId );
        
        if (strcmp($_SERVER['REMOTE_ADDR'], '217.23.11.119') == 0) {
            
        if (0 == strcmp(md5($secretCode . $paymentId . $orderId . $clientId . $paymentAmountBTC . $paymentAmountUSD . $receivedAmountBTC . $receivedAmountUSD . $status), $hash)) {
            
        
       $sum = number_format($order->order_total, 2, '.', ''); 
      if ((float)$sum != $receivedAmountUSD) {
                echo  'bad amount';
      } else {
            $order->payment_complete();
          echo 'OK';
      
      }
            
        }
        }
        
        
    } else {
        echo 'fail';
    }


    die();
}



  

}

/**
 * Add the gateway to WooCommerce
 **/
function add_spicepay_gateway($methods){
    $methods[] = 'WC_SPICEPAY';
    return $methods;
}

add_filter('woocommerce_payment_gateways', 'add_spicepay_gateway');
}
?>